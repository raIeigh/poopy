# RobloxStudio-Icon-Refresher
Thank you for checking out my solo texture pack. This is a all in one, you dont have to do anything after the steps below are done.

------------------------------------------------------------------------

Download the "NEW VERSION!!! RobloxStudio Icon Refresher" zip and extract it somewhere you are able to know where it is.

Then go to roblox studio, click file, then studio settings, then in directories, there should be a option called "Custom Icon Dir".

Click it, then click the folder you just extracted. Restart roblox studio, and your all set!

------------------------------------------------------------------------

Bye bye weird simplified icons, Hello classical!
